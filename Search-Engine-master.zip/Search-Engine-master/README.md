# Search-Engine
- A python based search engine for documents.
- This is a terminal based app which searches through various documents for a particular phrase provided by the user.
- It returns pages containing full or partial phrase and ranks documents using Okapi BM25
ranking function.
